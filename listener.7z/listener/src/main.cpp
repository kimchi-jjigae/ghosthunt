#include <iostream>
#include <SFML/Network.hpp>

int main()
{
    sf::TcpListener listener;

    // bind the listener to a port
    if (listener.listen(21212) != sf::Socket::Done)
    {
        std::cout << "it dint listn\n";
    }
    else
        std::cout << "it  listn :O\n";

    // accept a new connection
    sf::TcpSocket client;
    if (listener.accept(client) != sf::Socket::Done)
    {
        std::cout << "it dint accept client\n";
    }
    else
        std::cout << "accepted!\n";

    // use "client" to communicate with the connected client,
    // and continue to accept new connections with the listener

    char data[32];
    std::size_t received;

    // TCP socket:
    if (client.receive(data, 32, received) != sf::Socket::Done)
    {
        std::cout << "Received nothin\n";
    }
    else
    {
        std::cout << "Received " << received << " bytes\n";
        std::cout << "it says: " << data << "\n";
    }
}
